from Interaction import Interaction


class Game_Object:
    """It contains the information and implemention for game objects functionality"""
    def __init__(self,gameObj=None):
        """
        Interaction options are stored by default.
        """
        self.gameObj = gameObj
        
        self.interType=Interaction()
        self.interactionoptionsobj = {'Open':self.interType.mOpen,'Move':self.interType.mMove, 'Look':self.interType.mLook, 
                                      'TurnOff':self.interType.mTurnOff, 'TurnOn':self.interType.mTurnOn, 'PickUp':self.interType.mPickUp, 
                                      'Drop':self.interType.mDrop, 'Taste':self.interType.mTaste}
        self.interactionoptions = [ "Open", "Move", "Look", "TurnOff", "TurnOn", "PickUp", "Drop", "Taste" ]
    
    # def createGameObj(self):
    #     return self.gameRepoObj.createGameObj()
    
    # def selectGameObj(self,gameElemName):
    #     return self.gameRepoObj.fetchGameObj(gameElemName)

    def list_Current_Interaction_Options(self):
        """
        The available Interactions Options are shown
        """
        return self.interactionoptions


    def set_Current_Interaction_Options(self,gameInteraction):
        """
        The User Provided Interaction Option was checked and selected..
        """
        return self.interactionoptionsobj[gameInteraction]()

    def startCurrentInteraction(self):
        """
        The interaction will be initiated.
        """
        return "The interaction has been initiatied"

    def abort_Current_Interaction(self):
        """
        The Intraction was finshed and aborted.
        """
        return 'The current interaction previously initiated has been aborted\n'
