from Game import GameinteractionObj,GameInteractionChar

def eventManager():
    gameObj = GameinteractionObj()
    gameChar = GameInteractionChar()

    while True:
        print("1.Interaction with Object \n2.Interaction with Character \n3.Terminate")
        choice= int(input('Enter any of the above options: '))
        if choice == 1:
            while True:
                operationList = gameObj.objectInteraction()
                print(operationList)
                select= int(input('Enter any of the above options: '))
                if select==1:
                    print(gameObj.createGameObj())
                elif select==2:
                    print(gameObj.getGameObjects())
                    print(gameObj.inpGameobj())
                    print(gameObj.getInteraction())
                    print(gameObj.startInteraction())

                elif select==3:
                    print(gameObj.endConversation())
                    break
                else:
                    print("Please enter correct choice")
        elif choice == 2:
            while True:
                operationList = gameChar.charInteraction()
                print(operationList)
                opt = int(input('Enter any of the above options: '))
                if opt==1:
                    print(gameChar.createCharacter())
                elif opt==2:
                    out = gameChar.checkAvailability()
                    print(out)
                    if not out.startswith('Not'):
                        print(gameChar.initiateConversation())
                elif opt==3:
                    print(gameChar.endConversation())
                    break
                else:
                    print("Please enter correct choice")
        elif choice==3:
            print("Thanks for playing this game.")
            exit()

        else:
            print("Please enter correct choice")
if __name__== "__main__":
    eventManager()