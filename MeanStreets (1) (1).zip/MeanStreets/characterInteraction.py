import random
from gameObject import Game_Object
from gameObjRepo import GameObjRepo

class Character:
    """
    Greeting method and the method to answer the query are defined 
       in this class.
    """
    def __init__(self):
        game = GameObjRepo()
        self.game_object=random.choice(game.gameObjects)

    def query(self,query,charName):
        return f"Interacting with character {charName} \n Offers game object {self.game_object}"

    def mGreetUser(self,characterName):
        self.characterName = characterName
        return f'Hi,I am {characterName}. How can I help you out?'
        
    def endConversation(self):
        return "Thanks for conversation...."