from characterInteraction import Character

class CharacterRepository:
    """Class for maintaining character repository and creating new characters"""
    def __init__(self):
        self.characterList=["Tom","Jerry","Jack","Iron man"]
       
    def createCharacter(self,characterName):
        if characterName in self.characterList:
            return "Character already exists..."
        else:
            self.characterList.append(characterName)
            return "Character successfully created....."
    
    def listAvailableCharacters(self):
        return self.characterList
    
    def getCharacter(self,ch):
        if ch in self.characterList:
            return Character().mGreetUser(ch)
        else:
            return "Not found this character:enter valid character"
        