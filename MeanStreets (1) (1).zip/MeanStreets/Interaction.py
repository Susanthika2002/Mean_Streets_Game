class Interaction:
    def __init__(self):
        self.interactionType = None
        pass
    
    def mOpen(self):
        self.interactionType = 'Open'
        return "Type of interaction chosen is Open"
    def mLook(self):
        self.interactionType = 'Look'
        return "Type of interaction chosen is Look"
    
    def mClose(self):
        self.interactionType = 'Close'
        return "Type of interaction chosen is Close"
        
    def mMove(self):
        self.interactionType = 'Move'
        return "Type of interaction chosen is move"
        
    def mDrop(self):
        self.interactionType = 'Drop'
        return "Type of interaction chosen is drop"
    
    def mPickUp(self):
        self.interactionType = "Pickup"
        return "Type of interaction chosen is pickup"
        
    def mTaste(self):
        self.interactionType = 'Taste'
        return "Type of interaction chosen is taste"
    
    def mTurnOn(self):
        self.interactionType = 'Turnon'
        return "Type of interaction chosen is Turnon"
        
    def mTurnOff(self):
        self.interactionType = 'Turnoff'
        return "Type of interaction chosen is Turn Off"
        
    