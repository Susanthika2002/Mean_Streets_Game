from abc import ABC, abstractmethod
class GameInterface:
    """
    The GameInterface consists of abstract functions which will be override later.
    """

    @abstractmethod
    def listAvailableElements():
        pass

    @abstractmethod
    def isAvailable(game):
        pass

    @abstractmethod
    def isGameObject(game):
        pass

    @abstractmethod
    def list_Intraction_Types():
        pass

    @abstractmethod
    def start_Intraction(type):
        pass

    @abstractmethod
    def list_Current_Intraction_Options():
        pass

    @abstractmethod
    def set_Current_Intraction_Options(opt):
        pass

    @abstractmethod
    def Start_Current_Intraction():
        pass

    @abstractmethod
    def abort_Current_Intraction():
        pass