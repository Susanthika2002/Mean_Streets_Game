from gameObjRepo import GameObjRepo
from characterRepo import CharacterRepository
from GameInterface import GameInterface

class Scene(GameInterface):
    """This interactswithobject and also interactswithcharacter"""

    def __init__(self):
        self.charres = CharacterRepository()
        self.obj = GameObjRepo()
    
    def isAvailable(self, character):
        return self.charres.getCharacter(character)

    def listAvailableElements(self):
        return self.obj.gameobjects

    def isGameObject(self, gameobj):
        if gameobj in self.obj.gameobjects:
            return True
        else:
            return False
