from characterInteraction import Character
from gameObject import Game_Object
from gameObjRepo import GameObjRepo
from scene import Scene

class GameinteractionObj:
    """
    Interaction with Object
    """
    def __init__(self):
        self.scene = Scene()
        self.game_object = Game_Object()
        self.gameRepoObj = GameObjRepo()
        self.gameObj = None

    def objectInteraction(self):
        self.operationslist = "Enter:\n    1 to create a gameObject.\n    2 to initiate the conversation with game object.\n   3 to end conversation"
        return self.operationslist
    
    def selectGameObj(self,gameElemName):
        return self.gameRepoObj.fetchGameObj(gameElemName)
        
    def createGameObj(self):
        return self.gameRepoObj.createGameObj()
    
    def listGameObjects(self):
        return self.game_object.list_Current_Interaction_Options()
    
    def getGameObjects(self):
        return f"Available Game Objects {self.gameRepoObj.gameObjects}"
    
    def getInteraction(self):
        index = self.gameRepoObj.gameObjects.index(self.gameObj)
        return f"Available interactions for Game Object {self.gameObj}:\n {self.gameRepoObj.interactionTypesList[index]}"
    
    def inpGameobj(self):
        self.gameObj = input("Select a game object from the above list: ")
        if self.gameObj not in self.gameRepoObj.gameObjects:
            return "Selected game object is not available.Please create it first"  
        return f'Selected game object: {self.gameObj}'   
           
    def startInteraction(self):
        index = self.gameRepoObj.gameObjects.index(self.gameObj)
        gameInteraction = input("Choose an interaction from above list: ")
        if gameInteraction not in self.gameRepoObj.interactionTypesList[index]:
            return "Selected interaction is not available for the chosen gameObject."
        return self.game_object.set_Current_Interaction_Options(gameInteraction)
    
    def endConversation(self):
        return "Thanks for conversation."

class GameInteractionChar:
    """ 
    Interaction with Character
    """
    def __init__(self):
        self.operationslist = None
        self.scene = Scene()
        self.out = None
        self.charName = None

    def charInteraction(self):
        self.operationslist = "Enter:\n    1 to create a character.\n    2 to initiate the conversation.\n   3 to end conversation"
        return self.operationslist
    
    def createCharacter(self):
        charName = input("Enter character name to create: ")
        return self.scene.charres.createCharacter(charName)
    
    def listCharacters(self):
        return self.scene.charres.listAvailableCharacters()
    
    def checkAvailability(self):
        self.scene.charres.listAvailableCharacters()
        self.charName = input("Enter Charactername to start the conversation : \n")
        self.out = self.scene.isAvailable(self.charName)
        return self.out

    def initiateConversation(self):
        return self.queryQue()
        
              
    def queryQue(self):
        query = input("Enter query to send to the character")
        return Character().query(query,self.charName)

    def endConversation(self):
        return Character().endConversation()
   
