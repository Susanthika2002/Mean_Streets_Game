class GameObjRepo:
    """Has methods that are in interact with object"""
    def __init__(self):
        self.gameObjects=['Table','Knife','Mobile','powder']
        self.interactionTypesList = [["Open","Close","Move","Look"],
                                  ["Look","Move"],["TurnOff", "TurnOn", "PickUp","Move","Look"],
                                 ["Look","Taste"]]
        self.interactionoptions = [ "Open", "Move", "Look", "TurnOff", "TurnOn", "PickUp", "Drop", "Taste" ]

    def fetchGameObj(self,gameEleName):
        if gameEleName in self.gameObjects:
            index = self.gameObjects.index(gameEleName)
            return f"{gameEleName} was chosen as game object"
        else:
            return f"{gameEleName} game object is not found in the repository"
        
    def createGameObj(self):
        gameObj = input("Enter game object name to create: ")
        if gameObj in self.gameObjects:
            return f"{gameObj} already exists"
        else:
            print(f"Available interaction types {self.interactionoptions}")
            interactions = input("Enter the interactions from the above list separated by space: ").split()
            self.gameObjects.append(gameObj)
            self.interactionTypesList.append(interactions)
            return f"{gameObj} game object created successfully"
            
